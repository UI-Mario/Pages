#!/usr/bin/env bash

npm i
npm test
